#!/bin/bash
#
source /etc/profile.d/modules.sh
source ~/.bashrc
#
export OMP_NUM_THREADS=1
#
cd /home/davpoolechem/gamess
./rungms-dev w50_gamess-63rank.inp 00 63
