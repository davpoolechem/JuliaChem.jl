#!/bin/bash
#
source /etc/profile.d/modules.sh
source ~/.bashrc
#
export OMP_NUM_THREADS=1
#
cd /home/davpoolechem/shared/gamess
./rungms-dev Scaling-10000/w50_gamess-3rank.inp 00 3
